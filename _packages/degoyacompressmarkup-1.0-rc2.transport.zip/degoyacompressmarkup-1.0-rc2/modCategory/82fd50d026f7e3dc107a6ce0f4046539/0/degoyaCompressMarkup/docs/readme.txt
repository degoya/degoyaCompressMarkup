----------------------------
Extra: degoyaCompressMarkup
----------------------------
Version: 1.0.0rc2
Released: 2015-09-26
Author: Alexander Herling / DEGOYA medienkommunikation oHG <a.herling@degoya.de>
Based on the Minifier: phpwee-php-minifier from searchturbine - https://github.com/searchturbine/phpwee-php-minifier/tree/master
License: GNU GPLv2 (or later at your option)

About
A plugin for MODX Revolution (2.3+) to minify the output Markup (HTML5/inline CSS/inline JS).
The compression is at about 20% for each page depending on your markup.

Features
This MODX Revolution plugin that can be used to minify the output HTML5 markup.

Installation
Install Package via MODX Package Management.
The plugin will be installed and run on the event "OnWebPagePrerender".
That's it, have fun!

